rm kushguptarh*
ansible-galaxy collection build
ansible-galaxy collection publish kushguptarh-*
